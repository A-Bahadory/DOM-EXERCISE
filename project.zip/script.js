const userDiv = document.getElementById('user');
userDiv.innerHTML = 'Hello, ' + users[0].user.name.last + '!';